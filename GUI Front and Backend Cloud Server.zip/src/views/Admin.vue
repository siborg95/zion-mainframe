
<template>
  <div style="padding: 20px;">
    <h2>Admin Dashboard</h2>
    <p>This is the admin area. In future versions, logs and user control panels will appear here.</p>
  </div>
</template>

<script setup>
</script>
