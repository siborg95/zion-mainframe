
<template>
  <div style="font-size: 24px; padding: 50px;">
    ✅ App.vue is working — no router
  </div>
</template>

<script setup>
</script>
